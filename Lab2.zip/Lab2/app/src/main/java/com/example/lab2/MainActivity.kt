package com.example.lab2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button2.setOnClickListener(){

            val est = editText.text.toString().toDouble()/100
            val peso = editText2.text.toString().toInt() * 0.454

            if(est < 2.7 && est > 0){

                val res = est/(peso*peso)
                val intent : Intent = Intent(this, act1::class.java)
                intent.putExtra("res",res)
                startActivity(intent)

            }
            else{

                Toast.makeText(applicationContext, R.string.toast, Toast.LENGTH_LONG).show()

            }
        }
    }


}
