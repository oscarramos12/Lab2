package com.example.lab2

import android.content.Intent
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity

import kotlinx.android.synthetic.main.activity_act1.*
import kotlinx.android.synthetic.main.content_act1.*
import kotlinx.android.synthetic.main.fragment_first.*

class act1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_act1)
        setSupportActionBar(toolbar)

        val inte : Intent = intent
        val res = inte.getStringExtra("res")
        textView3.text = res


    }

}
